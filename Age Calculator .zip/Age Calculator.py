import tkinter as tk
from datetime import datetime

class AgeCalculator:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Age Calculator")
        self.window.geometry("400x300")  # Set window size
        self.window.resizable(False, False)  # Prevent resizing
        
        # Create main frame
        self.main_frame = tk.Frame(self.window, bg="#f0f0f0")
        self.main_frame.pack(fill="both", expand=True)
        
        # Create header label
        self.header_label = tk.Label(self.main_frame, text="Age Calculator", font=("Arial", 18, "bold"), bg="#f0f0f0")
        self.header_label.pack(pady=20)
        
        # Create input frame
        self.input_frame = tk.Frame(self.main_frame, bg="#f0f0f0")
        self.input_frame.pack(pady=10)
        
        # Create birth date label and entry
        self.birth_date_label = tk.Label(self.input_frame, text="Enter your birth date (YYYY-MM-DD):", bg="#f0f0f0")
        self.birth_date_label.pack()
        
        self.birth_date_entry = tk.Entry(self.input_frame, width=20, font=("Arial", 12))
        self.birth_date_entry.pack(pady=5)
        
        # Create button to calculate age
        self.calculate_button = tk.Button(self.input_frame, text="Calculate Age", command=self.calculate_age, bg="#007bff", fg="white", font=("Arial", 12))
        self.calculate_button.pack(pady=10)
        
        # Create result frame
        self.result_frame = tk.Frame(self.main_frame, bg="#f0f0f0")
        self.result_frame.pack(pady=10)
        
        # Create label to display age
        self.age_label = tk.Label(self.result_frame, text="", font=("Arial", 14), bg="#f0f0f0")
        self.age_label.pack()
        
        # Create label for error messages
        self.error_label = tk.Label(self.result_frame, text="", fg="red", bg="#f0f0f0")
        self.error_label.pack()
        
        # Create footer label
        self.footer_label = tk.Label(self.main_frame, text="© Developed by Marv114", font=("Arial", 10), bg="#f0f0f0")
        self.footer_label.pack(pady=10)
    
    def calculate_age(self):
        try:
            birth_date_str = self.birth_date_entry.get()
            birth_date = datetime.strptime(birth_date_str, "%Y-%m-%d")
            today = datetime.today()
            
            age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
            
            self.age_label['text'] = f"Your age is: {age} years"
            self.error_label['text'] = ""
        except ValueError:
            self.age_label['text'] = ""
            self.error_label['text'] = "Invalid date format. Please use YYYY-MM-DD."
    
    def run(self):
        self.window.mainloop()

if __name__ == "__main__":
    app = AgeCalculator()
    app.run()
